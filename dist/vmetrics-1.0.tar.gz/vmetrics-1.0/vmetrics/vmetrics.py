def hello(x):
    print(x)
    return

