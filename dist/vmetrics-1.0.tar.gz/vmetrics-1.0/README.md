# Validation Metrics
Python package for validating FALL3D with satellite retrievals.
